package com.example.data.repository

import com.example.data.model.CreateQuestionRequest
import com.example.data.model.CreateResultRequest
import com.example.data.model.CreateTestRequest
import com.example.data.model.CreateUserRequest
import com.example.data.model.EnrichedResult
import com.example.data.model.QuestionItem
import com.example.data.model.ResultItem
import com.example.data.model.TestItem
import com.example.data.model.UpdateResultRequest
import com.example.data.model.UpdateTestStatusRequest
import com.example.data.model.UpdateUserDeviceRequest
import com.example.data.model.UpdateUserRequest
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.io.IOException

sealed class Resource<out T> {
    data class Success<out T>(val data: T) : Resource<T>()
    data class Error(
        val message: String,
        val isNetworkError: Boolean = false,
        val isDeviceActiveOnAnotherPhone: Boolean = false
    ) : Resource<Nothing>()
    data object Loading : Resource<Nothing>()
}

class TestMitraRepository(
    private val clientProvider: SupabaseClientProvider
) {

    private fun extractErrorMessage(response: Response<*>): String {
        return try {
            val errorBody = response.errorBody()?.string()
            if (!errorBody.isNullOrBlank()) {
                if (errorBody.contains("JWT expired") || errorBody.contains("invalid claim")) {
                    "Session or API Key expired. Please check Supabase Settings."
                } else if (errorBody.contains("Failed to connect") || errorBody.contains("hostname")) {
                    "Unable to connect to Supabase URL. Please check network."
                } else {
                    errorBody.take(200)
                }
            } else {
                "Server responded with error code: ${response.code()}"
            }
        } catch (_: Exception) {
            "Network error (HTTP ${response.code()})"
        }
    }

    suspend fun checkConnection(): Resource<Boolean> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase credentials not configured. Please set URL & Anon Key.")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests(select = "id,test_name,duration,is_active", order = "id.asc")
            if (response.isSuccessful) {
                Resource.Success(true)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection or unable to reach Supabase: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Connection error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    suspend fun login(
        mobileNumber: String,
        password: String,
        currentDeviceId: String,
        forceSwitchDevice: Boolean = false
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase URL and API Key must be configured first.")
        }
        try {
            val api = clientProvider.getApiService()
            val cleanMobile = mobileNumber.trim()
            val response = api.getUserByMobile("eq.$cleanMobile")

            if (!response.isSuccessful) {
                val detailedError = extractErrorMessage(response)
                return@withContext Resource.Error(detailedError)
            }

            val users = response.body().orEmpty()
            if (users.isEmpty()) {
                return@withContext Resource.Error("મોબાઇલ નંબર મળ્યો નથી અથવા પાસવર્ડ ખોટો છે (User not found or invalid password)")
            }

            val matchedUser = users.firstOrNull {
                it.password?.trim() == password.trim()
            }

            if (matchedUser == null) {
                return@withContext Resource.Error("ખોટો પાસવર્ડ છે! (Invalid password)")
            }

            if (matchedUser.deviceId?.trim() == "DEACTIVATED") {
                return@withContext Resource.Error("This account has been deactivated by Super Admin. / આ એકાઉન્ટ સુપર એડમિન દ્વારા ડીએક્ટિવેટ કરવામાં આવ્યું છે.")
            }

            // Single Device Login Restriction for Students:
            if (!matchedUser.isTeacherOrAdmin) {
                val activeDevice = matchedUser.deviceId?.trim()
                val thisDevice = currentDeviceId.trim()

                // If active on another phone/device and user did not explicitly request device switch (e.g. after uninstall)
                if (!activeDevice.isNullOrBlank() && activeDevice != thisDevice && !forceSwitchDevice) {
                    return@withContext Resource.Error(
                        message = "This account is already active on another device. Please logout from the previous device first.\n\n(આ એકાઉન્ટ બીજા ડિવાઇસ પર પહેલેથી એક્ટિવ છે. પહેલાં જૂના ફોનમાંથી Logout કરો.)",
                        isDeviceActiveOnAnotherPhone = true
                    )
                }

                // Register current device ID in Supabase to make this device the single active device
                try {
                    api.updateUserDeviceId("eq.${matchedUser.id}", UpdateUserDeviceRequest(thisDevice))
                } catch (_: Exception) {
                    // Fail silently if column update issues
                }
            }

            Resource.Success(matchedUser.copy(deviceId = currentDeviceId))
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Login failed: ${e.localizedMessage ?: "Unable to connect to Supabase"}")
        }
    }

    suspend fun clearUserDeviceId(userId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured() || userId <= 0) {
            return@withContext Resource.Success(Unit)
        }
        try {
            val api = clientProvider.getApiService()
            // Reset device_id to empty in Supabase so another device can login cleanly
            api.updateUserDeviceId("eq.$userId", UpdateUserDeviceRequest(""))
            Resource.Success(Unit)
        } catch (_: Exception) {
            Resource.Success(Unit)
        }
    }

    suspend fun verifyUserSession(userId: Long, expectedDeviceId: String?): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured() || userId <= 0) {
            return@withContext Resource.Error("Session invalid")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getUserById("eq.$userId")
            if (!response.isSuccessful) {
                return@withContext Resource.Error("Account deleted / એકાઉન્ટ રદ કરવામાં આવ્યું છે")
            }
            val user = response.body()?.firstOrNull()
            if (user == null) {
                return@withContext Resource.Error("Account deleted / એકાઉન્ટ રદ કરવામાં આવ્યું છે")
            }

            if (user.deviceId?.trim() == "DEACTIVATED") {
                return@withContext Resource.Error("Account deactivated by Super Admin / એકાઉન્ટ ડીએક્ટિવેટ કરેલ છે")
            }

            if (!user.isTeacherOrAdmin && !expectedDeviceId.isNullOrBlank()) {
                val userDev = user.deviceId?.trim()
                if (!userDev.isNullOrBlank() && userDev != expectedDeviceId.trim()) {
                    return@withContext Resource.Error("Logged in on another device / અન્ય ડિવાઇસ પર લૉગિન થયેલ છે")
                }
            }

            Resource.Success(user)
        } catch (e: IOException) {
            Resource.Error("Network error", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Session error")
        }
    }

    suspend fun getAllUsers(): Resource<List<User>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getAllUsers()
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load users: ${e.localizedMessage}")
        }
    }

    suspend fun registerUser(
        name: String,
        mobileNumber: String,
        password: String,
        role: String = "student",
        callerUser: User? = null
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }

        // Security Authorization: Only Super Admin can register users/students/admins
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can add users. / માત્ર સુપર એડમિન જ યુઝર ઉમેરી શકે છે.")
        }

        val cleanName = name.trim()
        val cleanMobile = mobileNumber.trim()
        val cleanPassword = password.trim()
        val cleanRole = if (role.equals("admin", ignoreCase = true) || role.equals("teacher", ignoreCase = true)) "admin" else "student"

        // Validation 1: Name is required
        if (cleanName.isBlank()) {
            val label = if (cleanRole == "admin") "Admin Name" else "Student Name"
            return@withContext Resource.Error("$label is required / નામ ફરજિયાત છે")
        }

        // Validation 2: Mobile number is 10 digits
        if (cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() }) {
            return@withContext Resource.Error("કૃપા કરીને ૧૦ અંકનો સાચો મોબાઈલ નંબર દાખલ કરો (Valid 10-digit mobile required)")
        }

        // Validation 3: Password is required
        if (cleanPassword.isBlank()) {
            return@withContext Resource.Error("Password is required / પાસવર્ડ ફરજિયાત છે")
        }

        try {
            val api = clientProvider.getApiService()

            // Check if mobile already exists
            val checkResp = api.getUserByMobile("eq.$cleanMobile")
            if (checkResp.isSuccessful && !checkResp.body().isNullOrEmpty()) {
                return@withContext Resource.Error("આ મોબાઇલ નંબર પહેલેથી રજીસ્ટર છે! (Mobile number already exists)")
            }

            val req = CreateUserRequest(
                name = cleanName,
                mobileNumber = cleanMobile,
                password = cleanPassword,
                role = cleanRole,
                isSuperAdmin = false // Normal Admin and Student are always is_super_admin = false
            )
            val response = api.createUser(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: User(name = cleanName, mobileNumber = cleanMobile, role = cleanRole, isSuperAdmin = false)
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save user.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to add user: ${e.localizedMessage}")
        }
    }

    suspend fun updateUser(
        userId: Long,
        name: String,
        password: String? = null,
        callerUser: User? = null
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }

        // Security Authorization: Only Super Admin can edit users
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can edit users. / માત્ર સુપર એડમિન જ યુઝર એડિટ કરી શકે છે.")
        }

        val cleanName = name.trim()
        if (cleanName.isBlank()) {
            return@withContext Resource.Error("Name is required / નામ ફરજિયાત છે")
        }

        val cleanPassword = password?.trim()?.ifBlank { null }

        try {
            val api = clientProvider.getApiService()
            val req = UpdateUserRequest(
                name = cleanName,
                password = cleanPassword
            )
            val response = api.updateUser("eq.$userId", req)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: User(id = userId, name = cleanName, mobileNumber = "")
                Resource.Success(updated)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update user.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update user: ${e.localizedMessage}")
        }
    }

    suspend fun deleteUser(userId: Long, callerUser: User? = null): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }

        // Security Authorization: Only Super Admin can delete users
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete users. / માત્ર સુપર એડમિન જ ડીલીટ કરી શકે છે.")
        }

        // Prevent deleting root Super Admin
        if (userId == 1L || (callerUser != null && userId == callerUser.id)) {
            return@withContext Resource.Error("Cannot delete Super Admin account / સુપર એડમિન એકાઉન્ટ ડિલીટ કરી શકાતું નથી.")
        }

        try {
            val api = clientProvider.getApiService()
            val response = api.deleteUser("eq.$userId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete user: ${e.localizedMessage}")
        }
    }

    suspend fun toggleAdminActiveStatus(
        adminId: Long,
        deactivate: Boolean,
        callerUser: User? = null
    ): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }

        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can activate/deactivate admins.")
        }

        if (adminId == 1L) {
            return@withContext Resource.Error("Cannot deactivate Super Admin.")
        }

        try {
            val api = clientProvider.getApiService()
            val newDeviceId = if (deactivate) "DEACTIVATED" else ""
            val response = api.updateUserDeviceId("eq.$adminId", UpdateUserDeviceRequest(newDeviceId))
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update admin status: ${e.localizedMessage}")
        }
    }

    suspend fun getTests(): Resource<List<TestItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests()
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load tests: ${e.localizedMessage}")
        }
    }

    suspend fun updateTestStatus(testId: Long, isActive: Boolean): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.updateTestStatus("eq.$testId", UpdateTestStatusRequest(isActive))
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update test status: ${e.localizedMessage}")
        }
    }

    suspend fun getQuestionsForTest(testId: Long): Resource<List<QuestionItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getQuestionsForTest("eq.$testId")
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load questions: ${e.localizedMessage}")
        }
    }

    suspend fun submitResult(userId: Long, testId: Long, score: Double, userMobile: String = ""): Resource<ResultItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            var effectiveUserId = userId
            if (effectiveUserId <= 0 && userMobile.isNotBlank()) {
                try {
                    val userResp = api.getUserByMobile("eq.${userMobile.trim()}")
                    if (userResp.isSuccessful) {
                        effectiveUserId = userResp.body()?.firstOrNull()?.id ?: 0L
                    }
                } catch (_: Exception) {}
            }
            if (effectiveUserId <= 0) {
                try {
                    val allUsers = api.getAllUsers()
                    if (allUsers.isSuccessful && !allUsers.body().isNullOrEmpty()) {
                        effectiveUserId = allUsers.body()!!.first().id ?: 1L
                    } else {
                        effectiveUserId = 1L
                    }
                } catch (_: Exception) {
                    effectiveUserId = 1L
                }
            }

            val roundedScore = score.toLong()
            val req = CreateResultRequest(userId = effectiveUserId, testId = testId, score = roundedScore)

            // 1. First attempt: Supabase PostgREST native Upsert (resolution=merge-duplicates on conflict user_id,test_id)
            val upsertResponse = try {
                api.upsertResult(onConflict = "user_id,test_id", result = req)
            } catch (e: Exception) {
                null
            }

            if (upsertResponse != null && upsertResponse.isSuccessful) {
                val saved = upsertResponse.body()?.firstOrNull() ?: ResultItem(userId = effectiveUserId, testId = testId, score = score)
                return@withContext Resource.Success(saved)
            }

            // 2. Second attempt: If conflict (duplicate key / 23505) or update needed, directly update existing row via PATCH
            val patchResp = try {
                api.updateResult(
                    userIdFilter = "eq.$effectiveUserId",
                    testIdFilter = "eq.$testId",
                    body = UpdateResultRequest(score = roundedScore)
                )
            } catch (e: Exception) {
                null
            }

            if (patchResp != null && patchResp.isSuccessful && !patchResp.body().isNullOrEmpty()) {
                val updated = patchResp.body()!!.first()
                return@withContext Resource.Success(updated)
            }

            // 3. Third attempt: Standard insert if row did not exist
            val standardResponse = api.submitResult(req)
            if (standardResponse.isSuccessful) {
                val saved = standardResponse.body()?.firstOrNull() ?: ResultItem(userId = effectiveUserId, testId = testId, score = score)
                Resource.Success(saved)
            } else {
                // If standard insert hit duplicate key 23505, perform final PATCH
                val fallbackPatch = api.updateResult(
                    userIdFilter = "eq.$effectiveUserId",
                    testIdFilter = "eq.$testId",
                    body = UpdateResultRequest(score = roundedScore)
                )
                if (fallbackPatch.isSuccessful && !fallbackPatch.body().isNullOrEmpty()) {
                    val saved = fallbackPatch.body()!!.first()
                    Resource.Success(saved)
                } else if (fallbackPatch.isSuccessful) {
                    Resource.Success(ResultItem(userId = effectiveUserId, testId = testId, score = score))
                } else {
                    val errorMsg = extractErrorMessage(standardResponse)
                    android.util.Log.e("TestMitraRepo", "Submit result error: $errorMsg")
                    Resource.Error(errorMsg)
                }
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save result: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to save result: ${e.localizedMessage}")
        }
    }

    suspend fun getStudentResults(userId: Long, userMobile: String = ""): Resource<List<EnrichedResult>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            var effectiveUserId = userId
            if (effectiveUserId <= 0 && userMobile.isNotBlank()) {
                try {
                    val userResp = api.getUserByMobile("eq.${userMobile.trim()}")
                    if (userResp.isSuccessful) {
                        effectiveUserId = userResp.body()?.firstOrNull()?.id ?: 0L
                    }
                } catch (_: Exception) {}
            }

            val resultsResp = if (effectiveUserId > 0) {
                api.getResultsForUser("eq.$effectiveUserId")
            } else {
                api.getResults(select = "*", order = "id.desc")
            }
            val testsResp = try { api.getTests() } catch (_: Exception) { null }

            if (resultsResp.isSuccessful) {
                val results = resultsResp.body().orEmpty()
                val testsMap = testsResp?.body().orEmpty().associateBy { it.id ?: 0L }

                // Guarantee only the latest result per testId is mapped
                val distinctResults = results.distinctBy { it.testId }

                val enriched = distinctResults.map { res ->
                    val test = testsMap[res.testId]
                    EnrichedResult(
                        id = res.id,
                        userId = res.userId,
                        userMobile = userMobile,
                        testId = res.testId,
                        testName = test?.testName ?: "Test #${res.testId}",
                        testDuration = test?.duration ?: 0,
                        score = res.score,
                        createdAt = res.createdAt
                    )
                }
                Resource.Success(enriched)
            } else {
                Resource.Error(extractErrorMessage(resultsResp))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load results: ${e.localizedMessage}")
        }
    }

    suspend fun getAllEnrichedResults(): Resource<List<EnrichedResult>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val resultsResp = api.getResults(select = "*", order = "id.desc")
            val usersResp = try { api.getAllUsers() } catch (_: Exception) { null }
            val testsResp = try { api.getTests() } catch (_: Exception) { null }

            if (resultsResp.isSuccessful) {
                val results = resultsResp.body().orEmpty()
                val usersMap = usersResp?.body().orEmpty().associateBy { it.id ?: 0L }
                val testsMap = testsResp?.body().orEmpty().associateBy { it.id ?: 0L }

                val enriched = results.map { res ->
                    val user = usersMap[res.userId]
                    val test = testsMap[res.testId]
                    EnrichedResult(
                        id = res.id,
                        userId = res.userId,
                        userMobile = user?.mobileNumber ?: "User #${res.userId}",
                        testId = res.testId,
                        testName = test?.testName ?: "Test #${res.testId}",
                        testDuration = test?.duration ?: 0,
                        score = res.score,
                        createdAt = res.createdAt
                    )
                }
                Resource.Success(enriched)
            } else {
                Resource.Error(extractErrorMessage(resultsResp))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to fetch results.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load results: ${e.localizedMessage}")
        }
    }

    suspend fun createTest(testName: String, durationMinutes: Int): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val cleanName = testName.trim()
            val api = clientProvider.getApiService()
            val req = CreateTestRequest(testName = cleanName, duration = durationMinutes, isActive = true)
            val response = api.createTest(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: TestItem(testName = cleanName, duration = durationMinutes, isActive = true)
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to create test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to create test: ${e.localizedMessage}")
        }
    }

    suspend fun deleteTest(testId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteTest("eq.$testId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete test: ${e.localizedMessage}")
        }
    }

    suspend fun addQuestion(
        testId: Long,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String
    ): Resource<QuestionItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val req = CreateQuestionRequest(
                testId = testId,
                questionText = questionText.trim(),
                optionA = optionA.trim(),
                optionB = optionB.trim(),
                optionC = optionC.trim(),
                optionD = optionD.trim(),
                correctOption = correctOption.trim().uppercase()
            )
            val response = api.createQuestion(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: QuestionItem(
                    testId = testId,
                    questionText = questionText,
                    optionA = optionA,
                    optionB = optionB,
                    optionC = optionC,
                    optionD = optionD,
                    correctOption = correctOption
                )
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save question.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to save question: ${e.localizedMessage}")
        }
    }

    suspend fun deleteQuestion(questionId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteQuestion("eq.$questionId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete question: ${e.localizedMessage}")
        }
    }
}
