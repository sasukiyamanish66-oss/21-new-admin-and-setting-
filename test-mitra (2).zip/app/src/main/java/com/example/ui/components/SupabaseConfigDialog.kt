package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

// Master Password to access Settings / Supabase Configuration
private const val SETTINGS_MASTER_PASSWORD = "Man@2006"

@Composable
fun SupabaseConfigDialog(
    initialUrl: String,
    initialKey: String,
    repository: TestMitraRepository,
    onSave: (url: String, key: String) -> Unit,
    onDismiss: () -> Unit
) {
    // Password authentication step
    var isAuthenticated by remember { mutableStateOf(false) }
    var enteredPassword by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf<String?>(null) }

    // Supabase fields (visible after authentication)
    var url by remember { mutableStateOf(initialUrl) }
    var anonKey by remember { mutableStateOf(initialKey) }
    var testStatus by remember { mutableStateOf<String?>(null) }
    var isTesting by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf<Boolean?>(null) }

    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    if (!isAuthenticated) {
        // Step 1: Security Password Verification Dialog
        AlertDialog(
            onDismissRequest = onDismiss,
            modifier = Modifier.testTag("settings_password_dialog"),
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(40.dp),
                        shape = CircleShape,
                        color = MitraErrorLight
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MitraNavyPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Admin Security",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                        Text(
                            text = "સેટિંગ્સ પાસવર્ડ દાખલ કરો",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "સેટિંગ્સ અને Supabase કનેક્શન ખોલવા માટે પાસવર્ડ દાખલ કરવો જરૂરી છે.",
                        fontSize = 13.sp,
                        color = MitraTextSecondary
                    )

                    OutlinedTextField(
                        value = enteredPassword,
                        onValueChange = {
                            enteredPassword = it
                            passwordError = null
                        },
                        label = { Text("Settings Password") },
                        placeholder = { Text("Enter password") },
                        leadingIcon = {
                            Icon(Icons.Default.Key, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        },
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                if (enteredPassword == SETTINGS_MASTER_PASSWORD) {
                                    isAuthenticated = true
                                } else {
                                    passwordError = "ખોટો પાસવર્ડ છે! (Incorrect Password)"
                                }
                            }
                        ),
                        isError = passwordError != null,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    if (passwordError != null) {
                        Text(
                            text = passwordError!!,
                            color = MitraError,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Unlock / ખોલો",
                    onClick = {
                        focusManager.clearFocus()
                        if (enteredPassword == SETTINGS_MASTER_PASSWORD) {
                            isAuthenticated = true
                        } else {
                            passwordError = "ખોટો પાસવર્ડ છે! (Incorrect Password)"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "unlock_settings_button"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_password_button")
                ) {
                    Text("Cancel / રદ કરો", color = MitraTextSecondary)
                }
            }
        )
    } else {
        // Step 2: Supabase Settings Dialog (Unlocked)
        AlertDialog(
            onDismissRequest = onDismiss,
            modifier = Modifier.testTag("supabase_config_dialog"),
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Storage,
                        contentDescription = null,
                        tint = MitraNavyPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Supabase Connection",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                        Text(
                            text = "ડેટાબેઝ કનેક્શન સેટિંગ્સ",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Enter your Supabase Project URL and Anon/Public Key to connect the application.",
                        fontSize = 13.sp,
                        color = MitraTextSecondary
                    )

                    OutlinedTextField(
                        value = url,
                        onValueChange = {
                            url = it
                            testStatus = null
                            isSuccess = null
                        },
                        label = { Text("Supabase Project URL") },
                        placeholder = { Text("https://your-ref.supabase.co") },
                        leadingIcon = {
                            Icon(Icons.Default.Language, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("supabase_url_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    OutlinedTextField(
                        value = anonKey,
                        onValueChange = {
                            anonKey = it
                            testStatus = null
                            isSuccess = null
                        },
                        label = { Text("Supabase Anon / API Key") },
                        placeholder = { Text("eyJhbGciOi...") },
                        leadingIcon = {
                            Icon(Icons.Default.Key, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("supabase_key_input"),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    // Test Connection Button
                    MitraOutlinedButton(
                        text = if (isTesting) "Testing Connection..." else "Test Connection / ચકાસો",
                        onClick = {
                            if (url.isBlank() || anonKey.isBlank()) {
                                testStatus = "Please enter both URL and Anon Key"
                                isSuccess = false
                                return@MitraOutlinedButton
                            }
                            isTesting = true
                            testStatus = null
                            isSuccess = null
                            scope.launch {
                                onSave(url, anonKey)
                                val res = repository.checkConnection()
                                isTesting = false
                                when (res) {
                                    is Resource.Success -> {
                                        testStatus = "Successfully connected to Supabase!"
                                        isSuccess = true
                                    }
                                    is Resource.Error -> {
                                        testStatus = res.message
                                        isSuccess = false
                                    }
                                    else -> {}
                                }
                            }
                        },
                        enabled = !isTesting,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "test_connection_button"
                    )

                    if (testStatus != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSuccess == true) MitraGreenLight else Color(0xFFFEE2E2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isSuccess == true) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (isSuccess == true) MitraGreen else MitraError,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = testStatus!!,
                                    fontSize = 12.sp,
                                    color = if (isSuccess == true) Color(0xFF14532D) else Color(0xFF7F1D1D)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save & Connect / સાચવો",
                    onClick = {
                        onSave(url, anonKey)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "save_config_button"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_config_button")
                ) {
                    Text("Cancel / રદ કરો", color = MitraTextSecondary)
                }
            }
        )
    }
}
