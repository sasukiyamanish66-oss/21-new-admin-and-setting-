package com.example.ui.screens.student

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SessionManager
import com.example.data.model.EnrichedResult
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.components.SupabaseConfigDialog
import com.example.ui.components.TestMitraTopBar
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraOrangeLight
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentHomeScreen(
    user: User,
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    onStartTest: (testId: Long, testName: String, duration: Int) -> Unit,
    onLogout: () -> Unit
) {
    var testsList by remember { mutableStateOf<List<TestItem>>(emptyList()) }
    var completedResultsMap by remember { mutableStateOf<Map<Long, EnrichedResult>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var sessionInvalidMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    fun verifyAndLoadData() {
        isLoading = true
        errorMessage = null
        scope.launch {
            val userId = user.id ?: 0L
            val currentDeviceId = sessionManager.getDeviceId()

            // 1. Verify User Session in Supabase (Check if deleted or logged in on another device)
            if (userId > 0) {
                val sessionRes = repository.verifyUserSession(userId, currentDeviceId)
                if (sessionRes is Resource.Error && !sessionRes.isNetworkError) {
                    isLoading = false
                    sessionInvalidMessage = "તમારું એકાઉન્ટ એડમિન દ્વારા રદ કરવામાં આવ્યું છે અથવા બીજા ડિવાઇસ પર લૉગિન થયેલ છે.\n(Account removed or active on another device)"
                    return@launch
                }
            }

            // 2. Load Active Tests (Deactive tests are hidden for students)
            val testsRes = repository.getTests()
            if (testsRes is Resource.Success) {
                testsList = testsRes.data.filter { it.isTestActive }
            } else if (testsRes is Resource.Error) {
                errorMessage = testsRes.message
            }

            // 3. Load Student Submitted Results (For already-given indication)
            val resultsRes = repository.getStudentResults(userId, user.mobileNumber)
            if (resultsRes is Resource.Success) {
                completedResultsMap = resultsRes.data.associateBy { it.testId }
            }

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        verifyAndLoadData()
    }

    Scaffold(
        topBar = {
            TestMitraTopBar(
                title = "TEST MITRA",
                subtitle = "Student Portal • ${user.mobileNumber}",
                userRole = "Student",
                onRefresh = { verifyAndLoadData() },
                onLogout = {
                    scope.launch {
                        repository.clearUserDeviceId(user.id ?: 0L)
                        sessionManager.clearSession()
                        onLogout()
                    }
                }
            )
        },
        modifier = Modifier
            .fillMaxSize()
            .testTag("student_home_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight)
        ) {
            when {
                isLoading && testsList.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = MitraNavyPrimary,
                                strokeWidth = 3.5.dp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Loading tests from Supabase...\nટેસ્ટ લોડ થઈ રહ્યા છે...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { verifyAndLoadData() }
                    )
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Section Header Banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ઉપલબ્ધ એમસીક્યુ ટેસ્ટ",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MitraTextPrimary
                                )
                                Text(
                                    text = "Available Tests (${testsList.size})",
                                    fontSize = 12.sp,
                                    color = MitraTextSecondary
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MitraGreenLight
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = MitraGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${testsList.size} Active Tests",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraGreen
                                    )
                                }
                            }
                        }

                        if (testsList.isEmpty()) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = MitraTextMuted,
                                        modifier = Modifier.size(52.dp)
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = "હાલ કોઈ ટેસ્ટ ઉપલબ્ધ નથી",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraTextPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "શિક્ષક દ્વારા નવો ટેસ્ટ ઉમેરાય અથવા સક્રિય થાય પછી અહીં દેખાશે.",
                                        fontSize = 13.sp,
                                        color = MitraTextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    MitraPrimaryButton(
                                        text = "Refresh / રિફ્રેશ કરો",
                                        onClick = { verifyAndLoadData() }
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("tests_list"),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(testsList, key = { it.id ?: 0L }) { test ->
                                    val completedResult = completedResultsMap[test.id ?: 0L]
                                    StudentTestCard(
                                        test = test,
                                        completedResult = completedResult,
                                        onStartTest = {
                                            onStartTest(test.id ?: 0L, test.testName, test.duration)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Session Invalid Dialog (Auto logout)
    if (sessionInvalidMessage != null) {
        AlertDialog(
            onDismissRequest = {
                sessionManager.clearSession()
                onLogout()
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White,
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MitraError,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "સત્ર સમાપ્ત (Session Invalid)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MitraError
                )
            },
            text = {
                Text(
                    text = sessionInvalidMessage!!,
                    fontSize = 14.sp,
                    color = MitraTextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "OK / લૉગિન પેજ પર જાઓ",
                    onClick = {
                        sessionManager.clearSession()
                        onLogout()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        )
    }
}

@Composable
private fun StudentTestCard(
    test: TestItem,
    completedResult: EnrichedResult?,
    onStartTest: () -> Unit
) {
    val isCompleted = completedResult != null

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("test_card_${test.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.testName,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "MCQ Online Examination / એમસીક્યુ પરીક્ષા",
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isCompleted) MitraGreenLight else MitraBgLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.QueryBuilder,
                            contentDescription = null,
                            tint = if (isCompleted) MitraGreen else MitraNavyPrimary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isCompleted) "Score: ${completedResult?.score?.toInt() ?: 0}" else "${test.duration} min",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) MitraGreen else MitraNavyPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Indication if test is already given (Requirement 3)
            if (isCompleted) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MitraGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MitraGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "✓ આ ટેસ્ટ આપી દીધેલ છે (Test Already Given)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Start / Retake Test Button - Test is NEVER locked, student can always retake
            MitraSuccessButton(
                text = if (isCompleted) "Retake Test / ફરી ટેસ્ટ આપો" else "Start Test / ટેસ્ટ આપો",
                onClick = onStartTest,
                icon = if (isCompleted) Icons.Default.Refresh else Icons.Default.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
                height = 48.dp,
                testTag = "start_test_button_${test.id}"
            )
        }
    }
}

